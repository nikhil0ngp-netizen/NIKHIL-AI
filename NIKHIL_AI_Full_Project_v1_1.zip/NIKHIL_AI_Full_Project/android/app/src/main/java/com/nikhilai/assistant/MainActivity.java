package com.nikhilai.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;
    private PermissionRequest pendingRequest;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new NativeActions(), "Android");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                boolean audio = false;
                for (String r : request.getResources()) if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) audio = true;
                if (!audio) { request.deny(); return; }
                if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    pendingRequest = request;
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 44);
                } else request.grant(request.getResources());
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class NativeActions {
        @JavascriptInterface public void openAction(String action) {
            runOnUiThread(() -> {
                try {
                    Intent i;
                    switch (action) {
                        case "youtube":
                            i = getPackageManager().getLaunchIntentForPackage("com.google.android.youtube");
                            if (i == null) i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"));
                            break;
                        case "google":
                            i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"));
                            break;
                        case "maps":
                            i = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q="));
                            break;
                        case "calculator":
                            i = new Intent(Intent.ACTION_MAIN);
                            i.addCategory(Intent.CATEGORY_APP_CALCULATOR);
                            break;
                        case "settings":
                            i = new Intent(Settings.ACTION_SETTINGS);
                            break;
                        default:
                            Toast.makeText(MainActivity.this, "Action supported nahi hai", Toast.LENGTH_SHORT).show();
                            return;
                    }
                    startActivity(i);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Yeh app is phone par available nahi hai.", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 44 && pendingRequest != null) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) pendingRequest.grant(pendingRequest.getResources());
            else pendingRequest.deny();
            pendingRequest = null;
        }
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
