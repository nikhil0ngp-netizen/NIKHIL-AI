import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";

const app = express();
app.use(helmet());
app.use(cors({ origin: true, methods: ["GET", "POST"], allowedHeaders: ["Content-Type"] }));
app.use(express.json({ limit: "20kb" }));
app.use(rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: true, legacyHeaders: false }));

app.get("/health", (_req, res) => res.json({ ok: true, service: "NIKHIL AI backend" }));

app.post("/chat", async (req, res) => {
  try {
    const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
    const language = typeof req.body?.language === "string" ? req.body.language : "hi-IN";
    if (!message || message.length > 6000) return res.status(400).json({ error: "Message missing or too long." });
    if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: "Backend owner must configure OPENAI_API_KEY." });

    const languageName = language === "gu-IN" ? "Gujarati" : language === "en-IN" ? "English" : "Hindi/Hinglish";
    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        instructions: `You are NIKHIL AI, a helpful personal assistant. Reply naturally and concisely in ${languageName}, unless the user asks for another language. Do not claim you have performed phone actions unless the app explicitly confirms them. Ask before suggesting consequential actions.`,
        input: message,
        max_output_tokens: 700
      })
    });
    const data = await response.json();
    if (!response.ok) {
      console.error("OpenAI API error status:", response.status);
      return res.status(502).json({ error: "AI provider request failed. Check server logs and API account." });
    }
    const reply = (data.output || [])
      .flatMap(item => item.content || [])
      .filter(part => part.type === "output_text")
      .map(part => part.text)
      .join("\n").trim() || data.output_text || "Sorry, mujhe jawab nahi mila.";
    return res.json({ reply });
  } catch (error) {
    console.error("Chat request failed:", error?.message || "unknown error");
    return res.status(500).json({ error: "Unexpected backend error." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, "0.0.0.0", () => console.log(`NIKHIL AI backend listening on ${port}`));
